package com.rockchip.devicetest.aging;

import com.rockchip.devicetest.enumerate.AgingType;

public interface AgingCallback {

	public void onFailed(AgingType type);
	
}
