package com.rockchip.devicetest.constants;

public class ResourceConstants {

	public static final String AGING_CONFIG_FILE = "agingconfig.ini";
	
}
