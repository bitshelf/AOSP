package org.ido.iface;

import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CmdTest {

    public String FoundNode(String cmd) throws IOException, InterruptedException {

        boolean connect = false;
        Process p;
        String[] cmds = {"/system/bin/sh","-c",""};
        cmds[2] += cmd;

        p = Runtime.getRuntime().exec(cmds);
        int status = p.waitFor();
        InputStream input = p.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(input));
        StringBuffer buffer = new StringBuffer();
        String line;

        while ((line = in.readLine()) != null) {
            buffer.append(line);
        }

        if (buffer == null) {
            Log.e("buffer", "null");
            return "";
        }
        Log.v("Return ", buffer.toString());
        if (status != 0) {
            Log.e("status", String.valueOf(status));
        }
        return buffer.toString();
    }
}
