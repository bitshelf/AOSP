package com.imx.bookcase;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.ido.iface.SerialControl;

public class MyBootReceiver extends BroadcastReceiver {

    private static final String TAG = "IDO_DEMO";
    private SerialControl mSerialCtl0;
    private SerialControl mSerialCtl3;
    private SerialControl mSerialCtl4;
    private SerialControl mSerialCtl5;
    private SerialControl mSerialCtl7;
    private TestActivity testact;
    private short sData;
    private String reStr;

    public MyBootReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        final String TAG = "MyBootReceiver";
        String action = intent.getAction();
        if (action.equals(Intent.ACTION_BOOT_COMPLETED))
        {
           /* Intent i = new Intent(Intent.ACTION_RUN);
            i.setClass(context, Serial_test.class);/
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startService(i);
			*/


            Log.d(TAG,"System boot complete===>");

			Intent intentTemp = new Intent(context,MainActivity.class);
			intentTemp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intentTemp);

            serialInit();

//            byte test1[] = {(byte) 0x80, (byte) 0x80, (byte) 0xFF, (byte) 0x81,(byte) 0x81};
//            mSerialCtl5.write(test1);

            testact = new TestActivity();
            testact.onCreate();
            sData = testact.getsData();

            serialTest(mSerialCtl3,"ttyS3", (short) 0x0001);
            serialTest(mSerialCtl4,"ttyS4", (short) 0x0002);
            serialTest(mSerialCtl5,"ttyS5", (short) 0x0004);
            serialTest(mSerialCtl7,"ttyS7", (short) 0x0008);

            byte test[] = {(byte) 0x80, (byte) 0x80, (byte) (sData >> 8), (byte) (sData & 0x00FF), (byte) 0x81,(byte) 0x81};
            mSerialCtl0.write(test);   //写数据

           /* Intent mIntent = new Intent( );
            mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ComponentName comp = new ComponentName("com.airtalkee", "com.airtalkee.activity.AccountActivity");
            mIntent.setComponent(comp);
            mIntent.setAction("android.intent.action.VIEW");
            startActivity(mIntent);*/
            Log.d(TAG,"System boot complete");
        }
    }

    //串口初始化
    private void serialInit() {
        mSerialCtl0 = new SerialControl() {
            @Override
            protected void read(byte[] buf, int len) {
                Log.d(TAG,"UART RX len:" + len +",data:"+buf.toString());
                //读到数据；
            }
        };
        mSerialCtl0.init("/dev/ttyS0",9600,8,'N',1,0,10);
        mSerialCtl3 = new SerialControl() {
            @Override
            protected void read(byte[] buf, int len) {
                String str = new String(buf).substring(0, len);
                Log.d(TAG,"UART3 RX len:" + len +",data:"+str);
                reStr = str;
            }
        };
        mSerialCtl3.init("/dev/ttyS3",9600,8,'N',1,0,10);
        mSerialCtl4 = new SerialControl() {
            @Override
            protected void read(byte[] buf, int len) {
                String str = new String(buf).substring(0, len);
                Log.d(TAG,"UART4 RX len:" + len +",data:"+str);
                reStr = str;
            }
        };
        mSerialCtl4.init("/dev/ttyS4",9600,8,'N',1,0,10);
        mSerialCtl5 = new SerialControl() {
            @Override
            protected void read(byte[] buf, int len) {
                String str = new String(buf).substring(0, len);
                Log.d(TAG,"UART5 RX len:" + len +",data:"+str);
                reStr = str;
            }
        };
        mSerialCtl5.init("/dev/ttyS5",9600,8,'N',1,0,10);
        mSerialCtl7 = new SerialControl() {
            @Override
            protected void read(byte[] buf, int len) {
                String str = new String(buf).substring(0, len);
                Log.d(TAG,"UART7 RX len:" + len +",data:"+str);
                reStr = str;
            }
        };
        mSerialCtl7.init("/dev/ttyS7",9600,8,'N',1,0,10);
    }

    //串口收发测试
    private boolean sendReceivetest(SerialControl send, String str) {
        byte test[] = str.getBytes();
        send.write(test);
        try
        {
            Thread.currentThread().sleep(1000);//毫秒
        }
        catch(Exception e){}
        if (!str.equals(reStr)) {
            return false;
        }
        return true;
    }

    private void serialTest(SerialControl serial, String name, short errCode) {
        reStr = "";
//        for (int i = 0; i < 1; i++) {
            if (!sendReceivetest(serial, "test")) {
                sData |= errCode;
                Log.e("sData", String.valueOf(sData));
            }
//        }
    }
}