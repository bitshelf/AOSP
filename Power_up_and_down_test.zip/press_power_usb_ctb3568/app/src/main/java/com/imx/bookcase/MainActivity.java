package com.imx.bookcase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.ido.iface.*;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "IDO_DEMO";
    private SerialControl mSerialCtl0;
    private SerialControl mSerialCtl3;
    private SerialControl mSerialCtl4;
    private SerialControl mSerialCtl5;
    private SerialControl mSerialCtl7;

    private TextView textView;
    private String textStr;

    private short sData;
    private String reStr;
    private CmdTest cmdTest;
    private PingTest ping;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serialInit();
        byte test[] = {(byte) 0x80, (byte) 0x80, (byte) (sData >> 8), (byte) (sData & 0x00FF), (byte) 0x81,(byte) 0x81};
        mSerialCtl0.write(test);   //写数据

//        init();
//        sendsendsend((byte) 0x01);
//        serialTest(mSerialCtl3,"ttyS3", (short) 0x0001);
//        serialTest(mSerialCtl4,"ttyS4", (short) 0x0002);
//        serialTest(mSerialCtl5,"ttyS5", (short) 0x0004);
//        serialTest(mSerialCtl7,"ttyS7", (short) 0x0008);
//        sendsendsend((byte) 0x05);
//        try {
//            ethernetTest("eth0", (short) 0x0010);
//            lsNodetest("/dev/block/mmcblk1","TF", (short) 0x0040);
//            lsNodetest("/dev/sg0","sg0", (short) 0x0100);
//            lsNodetest("/dev/sg1","sg1", (short) 0x0200);
//            lsNodetest("/dev/sg2","sg2", (short) 0x0400);
//            lsNodetest("/dev/sg3","sg3", (short) 0x0800);
//            lsNodetest("/dev/sg4","sg4", (short) 0x1000);
//            lsNodetest("/dev/sg5","sg5", (short) 0x2000);
//            fourgModuletest("4G", (short) 0x4000);
//        } catch (IOException | InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        textView.setText(textStr + "结束。\n");
//        sendData();
    }

    private void sendsendsend (byte bt) {
        byte test[] = {(byte) 0x80, (byte) bt, (byte) 0x81};
        mSerialCtl3.write(test);
    }

    //初始化
    private void init(){
        textView = findViewById(R.id.textView1);
        sData = 0x0000;
        reStr = "";
        textStr = textView.getText().toString();
        cmdTest = new CmdTest();
        serialInit();
        ping = new PingTest();
    }

    //串口初始化
    private void serialInit() {
        mSerialCtl0 = new SerialControl() {
            @Override
            protected void read(byte[] buf, int len) {
                Log.d(TAG,"UART RX len:" + len +",data:"+buf.toString());
                //读到数据；
            }
        };
        mSerialCtl0.init("/dev/ttyS0",9600,8,'N',1,0,10);
//        mSerialCtl3 = new SerialControl() {
//            @Override
//            protected void read(byte[] buf, int len) {
//                String str = new String(buf).substring(0, len);
//                Log.d(TAG,"UART3 RX len:" + len +",data:"+str);
//                reStr = str;
//            }
//        };
//        mSerialCtl3.init("/dev/ttyS3",9600,8,'N',1,0,10);
//        mSerialCtl4 = new SerialControl() {
//            @Override
//            protected void read(byte[] buf, int len) {
//                String str = new String(buf).substring(0, len);
//                Log.d(TAG,"UART4 RX len:" + len +",data:"+str);
//                reStr = str;
//            }
//        };
//        mSerialCtl4.init("/dev/ttyS4",9600,8,'N',1,0,10);
//        mSerialCtl5 = new SerialControl() {
//            @Override
//            protected void read(byte[] buf, int len) {
//                String str = new String(buf).substring(0, len);
//                Log.d(TAG,"UART5 RX len:" + len +",data:"+str);
//                reStr = str;
//            }
//        };
//        mSerialCtl5.init("/dev/ttyS5",9600,8,'N',1,0,10);
//        mSerialCtl7 = new SerialControl() {
//            @Override
//            protected void read(byte[] buf, int len) {
//                String str = new String(buf).substring(0, len);
//                Log.d(TAG,"UART7 RX len:" + len +",data:"+str);
//                reStr = str;
//            }
//        };
//        mSerialCtl7.init("/dev/ttyS7",9600,8,'N',1,0,10);
    }

    private void sendData() {
        Log.v("sData", String.valueOf(sData));
        byte test[] = {(byte) 0x80, (byte) 0x80, (byte) (sData >> 8), (byte) (sData & 0x00FF), (byte) 0x81,(byte) 0x81};
        mSerialCtl3.write(test);   //写数据
    }

    //4G测试
    private void fourgModuletest(String name, short errCode) throws IOException, InterruptedException {
        String ret;
        for(int i = 0; i < 4; i++) {
            ret = cmdTest.FoundNode("ls /dev/ttyUSB" + String.valueOf(i));
            if (!ret.equals("/dev/ttyUSB" + String.valueOf(i))) {
                sData |= errCode;
                Log.e("sData", String.valueOf(sData));
                screenUpdate(name, errCode,false);
                return;
            }
        }
        screenUpdate(name, errCode,true);
    }

    //网络ping测试
    private int ethernetTestpass(String name) throws InterruptedException {
        int flag_net = 0;
        int status = 0;
        int eth_connect = 0;

        Enumeration allNetInterfaces = null;
        try {
            allNetInterfaces = NetworkInterface.getNetworkInterfaces();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        InetAddress ip = null;
        for(int i=0 ; i<3 ; i++ ) {

            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
                //String names = netInterface.getName();
                System.out.println(netInterface.getName());
                Enumeration addresses = netInterface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    ip = (InetAddress) addresses.nextElement();
                    if (!ip.isLoopbackAddress()) {
                        if (ip.isSiteLocalAddress()) {
                            flag_net = 1;
                            if (ip != null && ip instanceof Inet4Address && !ip.isLoopbackAddress()) {

                                System.out.println("本机的IP = " + ip.getHostAddress());
                                try {
                                    eth_connect = ping.Ping( "192.168.0.1", name);
//                                        eth1_connect = ping.Ping( "192.168.1.1");

                                    if (eth_connect == 0 /*&& eth1_connect == 0*/) {
                                        //成功
                                        System.out.println("ping one ok");
                                        flag_net = 2;
                                    }else{
                                        System.out.println("ping error");
                                        flag_net = 3;
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        } else {
                            Log.d(TAG, "未获取到本地IP,i:" + i);
                        }
                    }
                }
            }

            if ((flag_net == 2)) {
                break;
            } else {
                try {
                    Thread.sleep(500);
                    allNetInterfaces = NetworkInterface.getNetworkInterfaces();
                    Thread.sleep(500);
                } catch (SocketException e) {
                    e.printStackTrace();
                }
            }
        }

        if (flag_net == 0) {
            System.out.println("无法获取IP");
            status = 0;
        } else if (flag_net == 2) {
            System.out.println(" Net test Ping ok!");
            status = 1;
        } else if (flag_net == 3) {
            System.out.println(name + " ping error!");
            status = 2;
        }
        System.out.println(name + " ping status : " + status);
        return status;
    }

    private void ethernetTest(String name, short errCode) throws IOException, InterruptedException {
        if (ethernetTestpass(name) != 1) {
            sData |= errCode;
            Log.e("sData", String.valueOf(sData));
            screenUpdate(name, errCode,false);
        } else {
            screenUpdate(name, errCode,true);
        };
    }

    //串口收发测试
    private boolean sendReceivetest(SerialControl send, String str) {
        byte test[] = str.getBytes();
        send.write(test);
        try
        {
            Thread.currentThread().sleep(500);//毫秒
        }
        catch(Exception e){}
        if (!str.equals(reStr)) {
            return false;
        }
        return true;
    }

    private void serialTest(SerialControl serial, String name, short errCode) {
        for (int i = 0; i < 3; i++) {
            if (!sendReceivetest(serial, "test"+String.valueOf(i))) {
                sData |= errCode;
                Log.e("sData", String.valueOf(sData));
                screenUpdate(name, errCode,false);
                return;
            }
        }
        screenUpdate(name, errCode,true);
    }

    //节点测试
    private void lsNodetest(String node, String name, short errCode) throws IOException, InterruptedException {
        String ret = cmdTest.FoundNode("ls " + node);
        if (!ret.equals(node)) {
            sData |= errCode;
            Log.e("sData", String.valueOf(sData));
            screenUpdate(name, errCode,false);
            return;
        }
        screenUpdate(name, errCode,true);
    }

    //屏幕更新
    private void screenUpdate(String name, short errCode, boolean result) {
        String symbol;
        if (result) symbol = "√";
        else symbol = "×";

        if (name.length() < 3) name += "\t";
        textStr += name + "\t\t[" + hexTostring(errCode) + "]\t" + symbol + "\n";
        Log.v("textStr", textStr);
        textView.setText(textStr);
    }

    //错误码（十六进制）转为字符串
    private String hexTostring(short errCode) {
        switch (errCode) {
            case 0x0001:
                return "0x0001";    //ttyS3
            case 0x0002:
                return "0x0002";    //ttyS4
            case 0x0004:
                return "0x0004";    //ttyS5
            case 0x0008:
                return "0x0008";    //ttyS7
            case 0x0010:
                return "0x0010";    //eth0
            case 0x0020:
                return "0x0020";    //eth1
            case 0x0040:
                return "0x0040";    //TF
            case 0x0100:
                return "0x0100";    //sg0
            case 0x0200:
                return "0x0200";    //sg1
            case 0x0400:
                return "0x0400";    //sg2
            case 0x0800:
                return "0x0800";    //sg3
            case 0x1000:
                return "0x1000";    //sg4
            case 0x2000:
                return "0x2000";    //sg5
            case 0x4000:
                return "0x4000";    //4G
        }
        return "0x????";
    }
}
