package com.imx.bookcase;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.ido.iface.CmdTest;
import org.ido.iface.PingTest;
import org.ido.iface.SerialControl;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Timer;
import java.util.TimerTask;

public class TestActivity {

    private static final String TAG = "TEST_DEMO";

    private short sData;
    private PingTest ping;
    private CmdTest cmdTest;

    public void onCreate() {
        init();

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //do something
            }
        },5000);//延时5s执行

        try {
            lsNodetest("/dev/block/mmcblk1","TF", (short) 0x0040);
            lsNodetest("/dev/sg0","sg0", (short) 0x0100);
            lsNodetest("/dev/sg1","sg1", (short) 0x0200);
            lsNodetest("/dev/sg2","sg2", (short) 0x0400);
            lsNodetest("/dev/sg3","sg3", (short) 0x0800);
            lsNodetest("/dev/sg4","sg4", (short) 0x1000);
            fourgModuletest("4G", (short) 0x4000);
            ethernetTest("eth0", (short) 0x0010);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }


    public short getsData() {
        return sData;
    }

    //初始化
    private void init(){
        sData = 0x0000;
        ping = new PingTest();
        cmdTest = new CmdTest();
    }

    //网络ping测试
    private int ethernetTestpass(String name) throws InterruptedException {
        int flag_net = 0;
        int status = 0;
        int eth_connect = 0;

        Enumeration allNetInterfaces = null;
        try {
            allNetInterfaces = NetworkInterface.getNetworkInterfaces();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        InetAddress ip = null;
        for(int i=0 ; i<3 ; i++ ) {

            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
                //String names = netInterface.getName();
                System.out.println(netInterface.getName());
                Enumeration addresses = netInterface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    ip = (InetAddress) addresses.nextElement();
                    if (!ip.isLoopbackAddress()) {
                        if (ip.isSiteLocalAddress()) {
                            flag_net = 1;
                            if (ip != null && ip instanceof Inet4Address && !ip.isLoopbackAddress()) {

                                System.out.println("本机的IP = " + ip.getHostAddress());
                                try {
                                    eth_connect = ping.Ping( "192.168.0.1", name);
//                                        eth1_connect = ping.Ping( "192.168.1.1");

                                    if (eth_connect == 0 /*&& eth1_connect == 0*/) {
                                        //成功
                                        System.out.println("ping one ok");
                                        flag_net = 2;
                                    }else{
                                        System.out.println("ping error");
                                        flag_net = 3;
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        } else {
                            Log.d(TAG, "未获取到本地IP,i:" + i);
                        }
                    }
                }
            }

            if ((flag_net == 2)) {
                break;
            } else {
                try {
                    Thread.sleep(500);
                    allNetInterfaces = NetworkInterface.getNetworkInterfaces();
                    Thread.sleep(500);
                } catch (SocketException e) {
                    e.printStackTrace();
                }
            }
        }

        if (flag_net == 0) {
            System.out.println("无法获取IP");
            status = 0;
        } else if (flag_net == 2) {
            System.out.println(" Net test Ping ok!");
            status = 1;
        } else if (flag_net == 3) {
            System.out.println(name + " ping error!");
            status = 2;
        }
        System.out.println(name + " ping status : " + status);
        return status;
    }

    private void ethernetTest(String name, short errCode) throws IOException, InterruptedException {
        if (ethernetTestpass(name) != 1) {
            sData |= errCode;
            Log.e("sData", String.valueOf(sData));
        }
    }

    //节点测试
    private void lsNodetest(String node, String name, short errCode) throws IOException, InterruptedException {
        String ret = cmdTest.FoundNode("ls " + node);
        if (!ret.equals(node)) {
            sData |= errCode;
            Log.e("sData", String.valueOf(sData));
        }
    }

    //4G测试
    private void fourgModuletest(String name, short errCode) throws IOException, InterruptedException {
        String ret;
        for(int i = 0; i < 4; i++) {
            ret = cmdTest.FoundNode("ls /dev/ttyUSB" + String.valueOf(i));
            if (!ret.equals("/dev/ttyUSB" + String.valueOf(i))) {
                sData |= errCode;
                Log.e("sData", String.valueOf(sData));
                return;
            }
        }
    }
}
