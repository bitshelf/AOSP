package org.ido.iface;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class PingTest {

    public int Ping(String addr, String name) throws IOException, InterruptedException {

        int  connect =1 ;
        boolean connect_eth0 = false;
        Process p;
        p = Runtime.getRuntime().exec("ping -c 1 -w 1 " + addr);
        int status = p.waitFor();
        InputStream input = p.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(input));
        StringBuffer buffer = new StringBuffer();
        String line = "";

        while ((line = in.readLine()) != null) {
            buffer.append(line);
        }
        System.out.println("Return_" + name + buffer.toString());

        if (null != buffer && !buffer.toString().equals("")) {

            if (buffer.toString().indexOf(", 0% packet loss") > 0) {
                // 网络畅通
                connect_eth0 = true;
            } else {
                // 网络不畅通
                connect_eth0 = false;
            }
        }

        if (connect_eth0 == true) {
            connect=0;
        }
        return connect;
    }
}
